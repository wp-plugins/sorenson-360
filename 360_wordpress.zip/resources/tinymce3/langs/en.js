tinyMCE.addI18n("en.vipersvideoquicktags",{
	youtube : "Embed a video from YouTube",
	googlevideo : "Embed a video from Google Video",
	dailymotion : "Embed a video from DailyMotion",
	vimeo : "Embed a video from Vimeo",
	veoh : "Embed a video from Veoh",
	viddler : "Embed a video from Viddler",
	metacafe : "Embed a video from Metacafe",
	bliptv : "Embed a video from Blip.tv",
	flickrvideo : "Embed a video from Flickr",
	spike : "Embed an from IFILM / Spike.com",
	myspace : "Embed a video from MySpace",
	flv : "Embed a Flash Video (FLV) file",
	quicktime : "Embed a Quicktime video file",
	videofile : "Embed a generic video file"
});